# -*- coding:utf-8 -*-
import unittest
import HTMLTestRunner
import time
import ReadFile
import HttpFunc
import MysqlDB


class TestCases(unittest.TestCase):

    def setUp(self):
        HttpFunc.HttpFunc().get_root_path()
        self.rf = ReadFile.ReadFile()
        self.hf = HttpFunc.HttpFunc()
        self.md = MysqlDB.MysqlDB()

    def tearDown(self):
        self.hf.buf_close()
        self.md.cursor_close()
        self.md.conn_close()

    def test_rechargebankinfoget(self):
        u"""  充值绑卡查询  """

        token = self.hf.get_token()[0]  # 获得token值
        print u'获取的token值为：'+token
        location = self.hf.buf_tell()   # 获得token后，内存缓存区游标指针的位置
        header = [
            'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0',
            'Content-Type: application/json; charset=UTF-8',
            'X-Auth-Token:'+str(token)
        ]

        req_url = self.rf.get_option_value("http", "host")\
            + ':'\
            + self.rf.get_option_value("http", "port")\
            + self.rf.get_option_value('API_URL', 'api_url')

        print u'接口请求的地址为:'+req_url

        print u"请求返回报文：", self.hf.hf_post(req_url, headers=header, arg_type=0, location=location)

    def test_getbanklist(self):
        u""" 银行管理-获取银行列表 """
        token = self.hf.get_token()[0]  # 获得token值
        print u'获取的token值为：'+token
        location = self.hf.buf_tell()   # 获得token后，内存缓存区游标指针的位置
        header = [
            'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0',
            'Content-Type: application/json; charset=UTF-8',
            'X-Auth-Token:'+str(token)
        ]

        req_url = self.rf.get_option_value("http", "host")\
            + ':'\
            + self.rf.get_option_value("http", "port")\
            + self.rf.get_option_value('API_URL', 'getbanklist_url')
        print u'接口请求的地址为:'+req_url
        data = {
            "curPageNo": "1",
            "pageSize": "10"
        }
        print u"请求返回报文：", self.hf.hf_post(req_url, data, header, 2, location=location)
        assert(self.hf.get_code() == 200)

    def test_query_banklist(self):
        u""" 前台获取银行列表 """
        token = self.hf.get_token()[0]  # 获得token值
        print u'获取的token值为：'+token
        location = self.hf.buf_tell()   # 获得token后，内存缓存区游标指针的位置
        header = [
            'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0',
            'Content-Type: application/json; charset=UTF-8',
            'X-Auth-Token:'+str(token)
        ]

        req_url = self.rf.get_option_value("http", "host")\
            + ':'\
            + self.rf.get_option_value("http", "port")\
            + self.rf.get_option_value("API_URL", "bank_query_url")
        data = {
            "buysway": "00",  # 00:pc,01:app
            "service": "00"   # 00:个人网银，01：企业网银，02：快捷支付，03：提现
        }
        print u"请求返回报文：", self.hf.hf_post(req_url, params=data, headers=header, arg_type=2, location=location)
        assert(self.hf.get_code() == 200)

    def test_withdrawquery(self):
        u""" 提现绑卡查询 """
        token = self.hf.get_token()[0]  # 获得token值
        print u'获取的token值为：'+token
        location = self.hf.buf_tell()   # 获得token后，内存缓存区游标指针的位置
        header = [
            'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0',
            'Content-Type: application/json; charset=UTF-8',
            'X-Auth-Token:'+str(token)
        ]

        req_url = self.rf.get_option_value("http", "host")\
            + ':'\
            + self.rf.get_option_value("http", "port")\
            + self.rf.get_option_value("API_URL", "bank_query_withdraw")
        data = {}

        print u"请求返回报文：", self.hf.hf_post(req_url, params=data, headers=header, arg_type=2, location=location)
        assert(self.hf.get_code() == 200)



if __name__ == '__main__':

    suite = unittest.TestSuite(
        map(
            TestCases,
            [
                "test_rechargebankinfoget",
                "test_getbanklist",
                "test_query_banklist",
                "test_withdrawquery"
            ]
        )
    )
    # suite.addTest(TestCases('test_rechargebankinfoget'))
    now = time.strftime("%Y-%m-%d-%H_%M_%S", time.localtime(time.time()))
    HttpFunc.HttpFunc.create_report("test_api")

    filename = HttpFunc.HttpFunc.get_report("test_api")
    fp = file(filename, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(stream=fp, title=u'接口测试报告', description=u'包含三个接口，详情如下： ')
    runner.run(suite)
