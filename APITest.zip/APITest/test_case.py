# -*- coding:utf-8 -*-
import unittest
import HttpConfig
import HTMLTestRunner
import time, re
import Base64
import os, httpCurl, json
import readFile
import httpFunc


class TestCases(unittest.TestCase):

    def setUp(self):
        httpFunc.HttpFunc().get_root_path()
        self.rf = readFile.ReadFile()
        self.hf = httpFunc.HttpFunc()

        # self.hc = httpCurl.PyCurl()
        # self.hc1 = httpCurl.PyCurl()

    def tearDown(self):
        # self.hc.buffer_close()
        self.hf.buf_close()

    def test_rechargebankinfoget(self):
        u"""  获取充值绑卡查询  """

        token = self.hf.get_token()[0]  # 获得token值
        print u'获取的token值为：'+token
        location = self.hf.buf_tell()   # 获得token后，内存缓存区游标指针的位置
        header = [
            'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0',
            'Content-Type: application/json; charset=UTF-8',
            'X-Auth-Token:'+str(token)
        ]
        print header
        req_url = self.rf.get_option_value("http", "host")\
                  + ':'\
                  + self.rf.get_option_value("http", "port")\
                  + self.rf.get_option_value('API_URL', 'api_url')

        print u'接口请求的地址为:'+req_url

        print self.hf.hf_post(req_url, headers=header, arg_type=0, location=location)

    def test_getbanklist(self):
        u""" 银行管理-获取银行列表 """
        token = self.hf.get_token()[0]  # 获得token值
        print u'获取的token值为：'+token
        location = self.hf.buf_tell()   # 获得token后，内存缓存区游标指针的位置
        header = [
            'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0',
            'Content-Type: application/json; charset=UTF-8',
            'X-Auth-Token:'+str(token)
        ]

        req_url = self.rf.get_option_value("http", "host")\
                  + ':'\
                  + self.rf.get_option_value("http", "port")\
                  + self.rf.get_option_value('API_URL', 'getbanklist_url')
        print u'接口请求的地址为:'+req_url
        data = {
            "curPageNo": "1",
            "pageSize": "10"
        }
        print self.hf.hf_post(req_url, data, header, 2, location=location)


if __name__ == '__main__':

    suite = unittest.TestSuite(map(TestCases, ["test_rechargebankinfoget", "test_getbanklist"]))
    # suite.addTest(TestCases('test_rechargebankinfoget'))
    now = time.strftime("%Y-%m-%d-%H_%M_%S", time.localtime(time.time()))
    httpFunc.HttpFunc.create_report("test_api")

    filename = httpFunc.HttpFunc.get_report("test_api")
    fp = file(filename, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(stream=fp, title=u'接口测试报告', description=u'接口测试报告 ')
    runner.run(suite)
