import MysqlDB
import time

md = MysqlDB.MysqlDB()
md.execute("select * from user" )
print md.fetchone()
md.scroll(0, 'absolute')
print md.fetchone()

t
md.cursor_close()
md.conn_close()